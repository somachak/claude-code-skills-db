# Observability Guide

This is a starter support file for `improving-observability`.

## Purpose

Add project-specific guidance here to keep `SKILL.md` concise.

## Suggested content

- Decision rules
- Checklists
- Project conventions
- Examples
- Validator instructions
