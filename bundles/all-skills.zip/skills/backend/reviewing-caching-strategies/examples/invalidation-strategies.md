# Invalidation Strategies

This is a starter support file for `reviewing-caching-strategies`.

## Purpose

Add project-specific guidance here to keep `SKILL.md` concise.

## Suggested content

- Decision rules
- Checklists
- Project conventions
- Examples
- Validator instructions
