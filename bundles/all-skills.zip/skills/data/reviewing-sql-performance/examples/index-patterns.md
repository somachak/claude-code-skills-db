# Index Patterns

This is a starter support file for `reviewing-sql-performance`.

## Purpose

Add project-specific guidance here to keep `SKILL.md` concise.

## Suggested content

- Decision rules
- Checklists
- Project conventions
- Examples
- Validator instructions
